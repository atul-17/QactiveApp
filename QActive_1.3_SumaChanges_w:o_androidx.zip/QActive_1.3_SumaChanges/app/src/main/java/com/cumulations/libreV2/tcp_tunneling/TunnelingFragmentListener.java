package com.cumulations.libreV2.tcp_tunneling;

public interface TunnelingFragmentListener {
    void onFragmentTunnelDataReceived(TunnelingData tunnelingData);
}

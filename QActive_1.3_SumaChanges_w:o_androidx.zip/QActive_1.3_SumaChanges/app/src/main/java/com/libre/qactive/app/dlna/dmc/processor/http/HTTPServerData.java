package com.libre.qactive.app.dlna.dmc.processor.http;

import java.util.HashMap;
import java.util.Map;

public class HTTPServerData {
	public static String HOST = null;
	public static int PORT = -1;
	public static Map<String, String> GENERATEDURL = new HashMap<String, String>();
	public static boolean RUNNING = true;
}

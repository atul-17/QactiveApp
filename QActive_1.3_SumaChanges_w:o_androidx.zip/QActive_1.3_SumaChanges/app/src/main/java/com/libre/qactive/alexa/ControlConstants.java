package com.libre.qactive.alexa;

/**
 * Created by bhargav on 5/9/17.
 */

public class ControlConstants {
    public static final String PLAY_PAUSE = "PLAY_PAUSE";
    public static final String NEXT = "NEXT";
    public static final String PREVIOUS = "PREVIOUS";
    public static final String ALEXA_SOURCE_IMG_DELIMITER = "::::";
}

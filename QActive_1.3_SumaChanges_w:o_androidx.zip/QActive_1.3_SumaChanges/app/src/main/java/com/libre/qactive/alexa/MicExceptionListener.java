package com.libre.qactive.alexa;

/**
 * Created by Amit T on 11-08-2017.
 */

public interface MicExceptionListener {
    void micExceptionCaught(Exception e);
}
